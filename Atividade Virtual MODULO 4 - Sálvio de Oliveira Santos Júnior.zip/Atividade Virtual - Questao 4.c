/*Quest�o 04  
Fa�a um programa que calcule e imprima o fatorial de um n�mero, usando uma fun��o que receba um valor e retorne o fatorial desse valor.*/

#include <stdio.h>
#include <stdlib.h>

//FUN�AO PARA CALCULO DO FATORIAL
float fatorial(int num) 
{
	int fat = 1 , x;

	for ( x = 2 ; x <= num ; x++ )
		fat *= x;

	return fat;
}

//PRINCIPAL
main()

{
	 int num, fat=0;

	printf("\n*************************************************\n");
 	printf("\nDigite o numero para calcular o fatorial: ");
 	scanf("%d", &num);

	printf("\n*************************************************\n");
 	fat = fatorial(num);
 	
 	printf("\nfatorial do numero %d: %d\t\n", num, fat);
 	
 	printf("\n*************************************************\n");	
}
 
