/*Quest�o 01 
Fa�a um programa em C que leia um n�mero e ap�s a leitura, calcule e imprima a
raiz quadrada deste n�mero. Obs: Esta fun��o est� na biblioteca math.h.
*/
#include<stdio.h>
#include<stdlib.h>
#include<math.h>

//fun�ao
float raizqua ( float num)
{
	float raiz;
	raiz = sqrt(num);
	
	return (raiz);
}


int main()
//global
{
	float vnum, vraiz;
	
	printf("\nEscreva um numero = ");
	scanf("%f", &vnum);
	vraiz = raizqua(vnum);
	
	printf("\nResultado raiz quadrada = %.0f\n", vraiz);
	//nao vamos aprensentar numeros apos a virgula
	return 0;
}

