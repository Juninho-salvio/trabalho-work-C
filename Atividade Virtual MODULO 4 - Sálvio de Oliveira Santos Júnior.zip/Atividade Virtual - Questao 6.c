/*Quest�o 06  
Fa�a um programa em C que permita entrar com o valor de um produto e o percentual de desconto e imprimir o novo valor com base no percentual informado.
Para fazer o c�lculo, implemente uma fun��o.*/

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

//FUN��O Desconto.
float desconto (float precoProduto, float percentualDesc)
{
	float liquido;
	liquido = (precoProduto - (precoProduto * (percentualDesc/100)));
	return liquido;
}

//PRINCIPAL.
int main()

{
	setlocale(LC_ALL,"Portuguese");
	float precoProdutoBase, percentualDescBase, valorLiquido;

	printf("\n**********************************************************\n");
	printf("\n******************MERCEARIA UM IRM�O**********************\n\n");
	
	printf("\n Favor informar o pre�o do Produto: \t R$ ");
	scanf("%f", &precoProdutoBase);

	printf("\n Favor informar o percentual de desconto: \t");
	scanf("%f", &percentualDescBase);

// chamar a fun��o 
	valorLiquido = desconto(precoProdutoBase,percentualDescBase);
	
//Resultado do programa.	
	printf("\n**********************************************************\n");	
	printf("\n\t O valor do produto com o desconto �: R$ %.2f",valorLiquido);
	printf("\n\n**********************************************************\n");
	
	return 0;
}
