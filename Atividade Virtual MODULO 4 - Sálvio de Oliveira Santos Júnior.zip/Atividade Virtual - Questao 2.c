/*Quest�o 02 
Elabore um programa que tenha uma fun��o que retorne o reverso de um n�mero inteiro. Por exemplo, 742-> 247.*/

#include<stdio.h>
#include<stdlib.h>

//fun�ao para transformar a ordem inversa
int cifracalc ( int numero)
{
	int cifra; 
	//mostragem com numero negativo
		if( numero < 1)
		{
			numero = numero * -1;
			printf("-");
		}

	do
	//mostragem com numero positivo
		{
			printf("%d", numero % 10);
			numero /= 10;

		}
	while( numero > 0);
	
	return numero;
}

//Principal
main()

{
	int numero, resultado, cifra;

	printf("\nDigite uma ordem numerica inteiro = ");
	scanf("%d", &numero);
	
	printf("\n\n\nORDEM INVERSA = ");
	resultado = cifracalc(numero);
	printf("\n\n");
	
	return 0;
}
