/*Quest�o 05  
Construa um programa em C que leia um caractere (letra) e, por meio de uma fun��o, retorne se este caractere � uma consoante ou uma vogal. 
Ao final imprima o resultado. Obs: experimente utilizar o comando switch.*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>

//FUN�AO COM SWITCH
int letra(char c)
{
	 switch (tolower(c)) 
		{
 			case 'a':
 			return 1;
 			break;
 		
 			case 'e':
 			return 1;
 			break;
 		
 			case 'i':
 			return 1;
 			break;
 		
 			case 'o':
 			return 1;
 			break;
 		
 			case 'u':
 			return 1;
 			break;
 					
 			default:
 			return 0;
 		}
}


//PRINCIPAL
main()
{
 	char c;
 	int i;

	printf("\n******JOGO PARA SABER SE A LETRA EH**********\n");
	printf("\tCONSOANTE OU VOGAL:\n");

 	printf("\nDigite o caracter para verificar: ");
 	scanf("%c", &c);

 	i = letra(c);
 	
	if (i == 1)
		{
			printf("\nVogal\n");
		}
	else
			printf("\nConsoante\n");
}
