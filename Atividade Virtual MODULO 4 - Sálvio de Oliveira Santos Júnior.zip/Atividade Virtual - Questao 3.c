/*Quest�o 03 
Fa�a um programa em C que calcule a �rea de um ret�ngulo. O programa dever� ler a altura e a base. O c�lculo deve ser feito em uma fun��o. 
Ap�s calcular o programa deve imprimir o valor da �rea do ret�ngulo.*/

#include <stdio.h>
#include <stdlib.h>

//fun�ao DA AREA
float areaRetangulo(float base, float altura) 
{
	float area = (base * altura);
	return area;
}

//fun�ao PRINCIPAL
main()

{
	float vbase, valtura, varea;
	
	printf("\n************************************\n");
	printf("Informe a base do retangulo: \t");
	scanf("%f", &vbase);

	printf("Informe a altura do retangulo: \t");
	scanf("%f", &valtura);

	varea = areaRetangulo(vbase, valtura);

	printf("\n\nA area do retangulo e: \t%.0f \n", varea);
	
}
